package com.abc.otp;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.TimeUnit;

public class Main2Activity extends AppCompatActivity implements View.OnClickListener {






    private TextView b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,v1,v2,v3,v4;
    boolean f1,f2,f3,f4,timeup;
    private View bck;
    int counter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        InitView();
        clickMethod();
        final TextView mnumber = (TextView)findViewById(R.id.Timer);
        startTimer(mnumber);
    }




    private void startTimer(final TextView textView) {


        new CountDownTimer(120000, 1000) { // adjust the milli seconds here

            public void onTick(long millisUntilFinished) {
                long minut = TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished);
                long second = TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished));
                if(minut < 10){
                    if(second < 10){
                        textView.setText(""+String.format("0%d : 0%d",
                                TimeUnit.MILLISECONDS.toMinutes( millisUntilFinished),
                                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
                    }else{
                        textView.setText(""+String.format("0%d : %d",
                                TimeUnit.MILLISECONDS.toMinutes( millisUntilFinished),
                                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
                    }
                }else{
                    if(second < 10){
                        textView.setText(""+String.format("%d : 0%d",
                                TimeUnit.MILLISECONDS.toMinutes( millisUntilFinished),
                                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
                    }else{
                        textView.setText(""+String.format("%d : %d",
                                TimeUnit.MILLISECONDS.toMinutes( millisUntilFinished),
                                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
                    }
                }
            }
            public void onFinish() {
                textView.setText("Time Over!");
            }
        }.start();
    }



    private void InitView ()
    {
        f1 = f2 = f3 = f4 = false;
        timeup = true;
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7 = findViewById(R.id.b7);
        b8 = findViewById(R.id.b8);
        b9 = findViewById(R.id.b9);
        b0 = findViewById(R.id.b0);
        bck = findViewById(R.id.bck);
        v1 = findViewById(R.id.v1);
        v2 = findViewById(R.id.v2);
        v3 = findViewById(R.id.v3);
        v4 = findViewById(R.id.v4);
    }


    private void clickMethod() {
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);
        b7.setOnClickListener(this);
        b8.setOnClickListener(this);
        b9.setOnClickListener(this);
        b0.setOnClickListener(this);
        bck.setOnClickListener(this);

    }


    private void writeValue(String no)
    {

        if (f1 == false) {
            v1.setText(no);
            f1 = true;
        } else if (f2 == false) {
            v2.setText(no);
            f2 = true;
        } else if (f3 == false) {
            v3.setText(no);
            f3 = true;
        } else if (f4 == false) {
            v4.setText(no);
            f4 = true;
        }


    }


    @Override
    public void onClick(View view)
    {
        if(timeup==true) {
            switch (view.getId()) {
                case R.id.b1:
                    writeValue("1");
                    break;
                case R.id.b2:
                    writeValue("2");
                    break;
                case R.id.b3:
                    writeValue("3");
                    break;
                case R.id.b4:
                    writeValue("4");
                    break;
                case R.id.b5:
                    writeValue("5");
                    break;
                case R.id.b6:
                    writeValue("6");
                    break;
                case R.id.b7:
                    writeValue("7");
                    break;
                case R.id.b8:
                    writeValue("8");
                    break;
                case R.id.b9:
                    writeValue("9");
                    break;
                case R.id.b0:
                    writeValue("0");
                    break;
                case R.id.bck:
                    if (f4 == true) {
                        v4.setText("-");
                        f4 = false;
                    } else if (f3 == true) {
                        v3.setText("-");
                        f3 = false;
                    } else if (f2 == true) {
                        v2.setText("-");
                        f2 = false;
                    } else if (f1 == true) {
                        v1.setText("-");
                        f1 = false;
                    }
                    break;
                default:
                    break;
            }
        }
        else
            Toast.makeText(this, "Time is up", Toast.LENGTH_SHORT).show();
    }



}
