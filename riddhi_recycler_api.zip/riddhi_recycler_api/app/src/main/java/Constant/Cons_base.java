package Constant;

/**
 * Created by jay on 21/5/2018.
 */

public class Cons_base {

    public static String baseUrl="http://puzzel-app.maldechavda.me/api/";
}
