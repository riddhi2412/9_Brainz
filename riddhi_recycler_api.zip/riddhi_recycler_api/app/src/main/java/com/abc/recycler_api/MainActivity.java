package com.abc.recycler_api;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import Constant.Cons_base;
import Interface.RequestInterface;
import Module.SucessOutput;
import Module.Tests;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Info> infoList = new ArrayList<>();
    private RecyclerView recyclerView;
    private AdapterClass mAdapter;
    private String id,name,msg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recycler_view);
        mAdapter = new AdapterClass(infoList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        recyclerView.setAdapter(mAdapter);

        getApiData();
    }


    public void getApiData(){

        final ProgressDialog pg = new ProgressDialog(MainActivity.this);
        pg.setMessage("Loading..");
        pg.show();
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(100, TimeUnit.SECONDS)
                .readTimeout(100, TimeUnit.SECONDS).build();
        Retrofit retrofit = new Retrofit.Builder().client(client).baseUrl(Cons_base.baseUrl).addConverterFactory(GsonConverterFactory.create(gson)).build();
        final RequestInterface requestInterface = retrofit.create(RequestInterface.class);
        final Call<SucessOutput> sucessOutputCall = requestInterface.sucessOutputMethod();


        sucessOutputCall.enqueue(new Callback<SucessOutput>() {
            @Override
            public void onResponse(Call<SucessOutput> call, Response<SucessOutput> response) {
               pg.dismiss();
                if(response.isSuccessful()){
                    if(response.body().getSuccess()){
                        for(int i=0;i<response.body().getTests().size();i++)
                        {
                            id= String.valueOf(response.body().getTests().get(i).getId());
                            name=response.body().getTests().get(i).getName();
                            msg=response.body().getTests().get(i).getMessage1();
                            Info information=new Info(name,id,msg);
                            infoList.add(information);
                        }
                        mAdapter.notifyDataSetChanged();

                    }
                    else {
                        Toast.makeText(MainActivity.this, "api problem", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(MainActivity.this, "try again", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<SucessOutput> call, Throwable t) {
                pg.dismiss();
                Toast.makeText(MainActivity.this, "please check your internet", Toast.LENGTH_SHORT).show();
            }
        });

    }







    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
