package com.abc.recycler_api;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import Module.Tests;

/**
 * Created by riddhi on 22/5/2018.
 */

public class AdapterClass extends RecyclerView.Adapter<AdapterClass.MyViewHolder> {

    private List<Info> infoList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView name,id,msg;

        public MyViewHolder(View view) {
            super(view);
            name = (TextView) view.findViewById(R.id.tv_name);
            id = (TextView) view.findViewById(R.id.tv_id);
            msg = (TextView) view.findViewById(R.id.tv_msg);
        }
    }


    public AdapterClass(List<Info> infoList) {
        this.infoList = infoList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.info_row_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Info info = infoList.get(position);
        holder.name.setText(info.getName());
        holder.id.setText(info.getId());
        holder.msg.setText(info.getMsg());
    }

    @Override
    public int getItemCount() {
        return infoList.size();
    }
}