package com.abc.recycler_api;

/**
 * Created by riddhi on 21/5/2018.
 */

public class Info {

    String Name,Id,Msg;

    public Info() {
    }

    public Info(String name, String id, String msg) {
        Name = name;
        Id = id;
        Msg = msg;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getMsg() {
        return Msg;
    }

    public void setMsg(String msg) {
        Msg = msg;
    }
}
