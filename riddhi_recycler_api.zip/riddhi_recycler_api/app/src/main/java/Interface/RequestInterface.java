package Interface;

import Module.SucessOutput;
import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by riddhi on 21/5/2018.
 */

public interface RequestInterface {

    @GET("v1/tests")

    Call<SucessOutput> sucessOutputMethod();
}
