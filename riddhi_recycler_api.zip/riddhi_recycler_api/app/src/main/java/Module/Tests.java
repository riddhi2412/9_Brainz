package Module;

public class Tests {
    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("updated_at")
    private String updated_at;
    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("created_at")
    private String created_at;
    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("message3")
    private String message3;
    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("message2")
    private String message2;
    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("message1")
    private String message1;
    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("name")
    private String name;
    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("id")
    private int id;

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getMessage3() {
        return message3;
    }

    public void setMessage3(String message3) {
        this.message3 = message3;
    }

    public String getMessage2() {
        return message2;
    }

    public void setMessage2(String message2) {
        this.message2 = message2;
    }

    public String getMessage1() {
        return message1;
    }

    public void setMessage1(String message1) {
        this.message1 = message1;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
