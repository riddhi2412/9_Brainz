package Module;

import java.util.List;

/**
 * Created by riddhi on 21/5/2018.
 */

public class SucessOutput {


    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("tests")
    private List<Tests> tests;
    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("success")
    private boolean success;

    public List<Tests> getTests() {
        return tests;
    }

    public void setTests(List<Tests> tests) {
        this.tests = tests;
    }

    public boolean getSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }
}
