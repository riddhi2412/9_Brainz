package com.abc.quizapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by Riddhi on 25/5/2018.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Player.db";
    public static final String TABLE_NAME = "score_table";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "NAME";
    public static final String COL_3 = "SCORE";
    public SQLiteDatabase sqLiteDatabase = getWritableDatabase();

    public static ArrayList<detail> detaillist2 = new ArrayList<detail>();

    private DatabaseHelper dbhelper;
    private Context context;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME + " ("+COL_1+"INTEGER PRIMARY KEY AUTOINCREMENT,NAME TEXT,SCORE INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }


    public void insertData( String name, int score) {
        // get writable database as we want to write data


        ContentValues values = new ContentValues();
        // `id` and `timestamp` will be inserted automatically.
        // no need to add them
        values.put("NAME", name);
        values.put("SCORE",score);

        // insert row
        long id = sqLiteDatabase.insert(TABLE_NAME, null, values);

        // close db connection
        sqLiteDatabase.close();

        // return newly inserted row id
       // getAllNotes();
    }


    public DatabaseHelper open() throws SQLException {

        dbhelper = new DatabaseHelper(context);
        sqLiteDatabase = this.getWritableDatabase();
        return this;
    }

    public ArrayList<detail> getAllNotes() {
        ArrayList<detail> notes = new ArrayList<detail>();

        // Select All Query
        String selectQuery = "SELECT  * FROM "+TABLE_NAME;

        Cursor cursor = sqLiteDatabase.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
       try {
           if (cursor.moveToFirst()) {
               do {
                   Log.e("name : ",""+cursor.getString(cursor.getColumnIndex("NAME")));
                   Log.e("score : ",""+cursor.getInt(cursor.getColumnIndex("SCORE")));
                   String name = cursor.getString(cursor.getColumnIndex("NAME"));
                   int score = cursor.getInt(cursor.getColumnIndex("SCORE"));
                   detail note = new detail();
                   note.setId(12);
                   note.setName(name);
                   note.setScore(score);
                   notes.add(note);
               } while (cursor.moveToNext());
           }
       }catch (Exception e){
           e.printStackTrace();
       }

        // close db connection
        sqLiteDatabase.close();

        // return notes list
        return notes;
    }
}
