/*


package com.abc.quizapp;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.app.Activity;
import android.support.annotation.ColorInt;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.widget.RadioButton;
import android.widget.RadioGroup;


public class RadioQuestion extends AppCompatActivity {


    private RadioButton rb_1,rb_2,rb_3,rb_4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.radio_question);

        final RadioGroup rg = (RadioGroup) findViewById(R.id.rg);
        rb_1 =  findViewById(R.id.rb_1);
        rb_2 =  findViewById(R.id.rb_2);
        rb_3 =  findViewById(R.id.rb_3);
        rb_4 =  findViewById(R.id.rb_4);




        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (rb_1.isChecked()) {
                    rb_2.setEnabled(false);
                    rb_3.setEnabled(false);
                    rb_4.setEnabled(false);
                    if (rb_1.getText().equals("Holi")) {
                        rb_1.setTextColor(Color.BLUE);
                        rb_2.setTextColor(Color.BLACK);
                        rb_3.setTextColor(Color.BLACK);
                        rb_4.setTextColor(Color.BLACK);

                    }
                    else {
                        rb_1.setTextColor(Color.RED);
                        findAnswer();
                    }
                }
                if (rb_2.isChecked() ) {
                    rb_1.setEnabled(false);
                    rb_3.setEnabled(false);
                    rb_4.setEnabled(false);
                    if (rb_2.getText().equals("Holi")) {
                        rb_1.setTextColor(Color.BLACK);
                        rb_2.setTextColor(Color.BLUE);
                        rb_3.setTextColor(Color.BLACK);
                        rb_4.setTextColor(Color.BLACK);

                    }
                    else {
                        rb_2.setTextColor(Color.RED);
                        findAnswer();
                    }
                }
                if (rb_3.isChecked() ) {
                    rb_1.setEnabled(false);
                    rb_2.setEnabled(false);
                    rb_4.setEnabled(false);
                    if (rb_3.getText().equals("Holi")) {
                        rb_1.setTextColor(Color.BLACK);
                        rb_2.setTextColor(Color.BLACK);
                        rb_3.setTextColor(Color.BLUE);
                        rb_4.setTextColor(Color.BLACK);

                    }
                    else {
                        rb_3.setTextColor(Color.RED);
                        findAnswer();
                    }
                }
                if (rb_4.isChecked() ) {
                    rb_1.setEnabled(false);
                    rb_2.setEnabled(false);
                    rb_3.setEnabled(false);
                    if (rb_4.getText().equals("Holi")) {
                        rb_1.setTextColor(Color.BLACK);
                        rb_2.setTextColor(Color.BLACK);
                        rb_3.setTextColor(Color.BLACK);
                        rb_4.setTextColor(Color.BLUE);

                    }
                    else {
                        rb_4.setTextColor(Color.RED);
                        findAnswer();
                    }
                }
            }
        });
    }

    private void findAnswer(){
        if (rb_1.getText().equals("Holi")){
            rb_1.setTextColor(Color.BLUE);
            }
        else if (rb_2.getText().equals("Holi")){
            rb_2.setTextColor(Color.BLUE);
            }
        else if (rb_3.getText().equals("Holi")){
            rb_3.setTextColor(Color.BLUE);
            }
        else if (rb_4.getText().equals("Holi")){
            rb_4.setTextColor(Color.BLUE);
           }
    }
        }
*/



package com.abc.quizapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

import static android.graphics.Color.GREEN;
import static android.graphics.Color.RED;
import static android.graphics.Color.WHITE;
import static android.graphics.Color.parseColor;

public class RadioQuestion extends AppCompatActivity implements View.OnClickListener {



    private ImageView home;
    RadioGroup rg;
    private RadioButton btn_opta, btn_optb, btn_optc, btn_optd;
    TextView tv_question,tv_Score;
    int wrong=0,score=0;
    boolean click=false;

    private String answer;

    Random random;
    private Button btn_next;


    Question question = new Question();
    int questionLength = question.questions.length;
    private int questionNumber=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.radio_question);
        Toolbar toolbar =  findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        random = new Random();



        btn_opta = findViewById(R.id.btn_opta);
        btn_opta.setOnClickListener(this);
        btn_optb = findViewById(R.id.btn_optb);
        btn_optb.setOnClickListener(this);
        btn_optc = findViewById(R.id.btn_optc);
        btn_optc.setOnClickListener(this);
        btn_optd = findViewById(R.id.btn_optd);
        btn_optd.setOnClickListener(this);
        btn_next=findViewById(R.id.btn_next);


        tv_question = findViewById(R.id.tv_question);
        tv_Score=findViewById(R.id.tv_Score);
        NextQuestion(random.nextInt(questionLength));

        home=findViewById(R.id.home);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(RadioQuestion.this);
                alertDialogBuilder
                        .setMessage("Are you sure you want to go back to home?")
                        .setCancelable(false)
                        .setPositiveButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        })
                        .setNegativeButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                startActivity(new Intent(getApplicationContext(), PlayExit.class));
                            }
                        });
                alertDialogBuilder.show();

            }
        });


        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    clearChecked();
                    clearColor();

                    NextQuestion(random.nextInt(questionLength));
                    Log.e("tag", "working");
                }

                catch(Exception e){
                    e.printStackTrace();

                }
            }

        });

    }



    public void onBackPressed() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setTitle("Closing Application");
        alertDialog.setMessage(" " + "Are you sure you want to close this app?");
        alertDialog.setPositiveButton("EXIT", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {
                finishAffinity();
            }
        });
        alertDialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.btn_opta:
                if(click==false){
                    if(btn_opta.getText() == answer){
                        btn_opta.setBackgroundColor(GREEN);
                        score=(score+5);
                    }else{
                        btn_opta.setBackgroundColor(RED);
                        score=(score-5);
                        makeGreen();
                        if(wrong==0 || wrong==1)
                            wrong++;
                    }
                    tv_Score.setText(""+score);
                    btn_optb.setEnabled(false);
                    btn_optc.setEnabled(false);
                    btn_optd.setEnabled(false);
                    click=true;
                    break;}

            case R.id.btn_optb:
                if(click==false){
                    if(btn_optb.getText() == answer){
                        btn_optb.setBackgroundColor(GREEN);
                        score=(score+5);
                    }else{
                        btn_optb.setBackgroundColor(RED);
                        makeGreen();
                        score=(score-5);
                        if(wrong==0 || wrong==1)
                            wrong++;

                    }
                    tv_Score.setText(""+score);
                    btn_opta.setEnabled(false);
                    btn_optc.setEnabled(false);
                    btn_optd.setEnabled(false);
                    click=true;
                    break;}

            case R.id.btn_optc:
                if(click==false){
                    if(btn_optc.getText() == answer){
                        btn_optc.setBackgroundColor(GREEN);
                        score=(score+5);
                    }else {
                        btn_optc.setBackgroundColor(RED);
                        makeGreen();
                        score = (score - 5);
                        if (wrong == 0 || wrong == 1)
                            wrong++;

                    }
                    tv_Score.setText(""+score);
                    btn_optb.setEnabled(false);
                    btn_opta.setEnabled(false);
                    btn_optd.setEnabled(false);
                    click=true;
                    break;}

            case R.id.btn_optd:
                if(click==false){
                    if(btn_optd.getText() == answer){
                        btn_optd.setBackgroundColor(GREEN);
                        score=(score+5);
                    }else{
                        btn_optd.setBackgroundColor(RED);
                        makeGreen();
                        score=(score-5);
                        if(wrong==0 || wrong==1)
                            wrong++;

                    }
                    tv_Score.setText(""+score);
                    btn_optb.setEnabled(false);
                    btn_optc.setEnabled(false);
                    btn_opta.setEnabled(false);
                    click=true;
                    break;}
        }
    }

    private void makeGreen() {

        if(btn_opta.getText().equals(answer))
            btn_opta.setBackgroundColor(GREEN);
        else if(btn_optb.getText().equals(answer))
            btn_optb.setBackgroundColor(GREEN);
        else if(btn_optc.getText().equals(answer))
            btn_optc.setBackgroundColor(GREEN);
        else if(btn_optd.getText().equals(answer))
            btn_optd.setBackgroundColor(GREEN);
    }

    private void GameOver(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(RadioQuestion.this);
        alertDialogBuilder
                .setMessage("Game Over!!\nYour score is  "+score)
                .setCancelable(false)
                .setPositiveButton("New Game", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(getApplicationContext(), PlayExit.class));
                    }
                })
                .setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finishAffinity();
                    }
                });
        alertDialogBuilder.show();

    }

    private void winGame() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(RadioQuestion.this);
        alertDialogBuilder
                .setMessage("Congrats!!You win this game")
                .setCancelable(false)
                .setPositiveButton("New Game", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(getApplicationContext(), RadioQuestion.class));
                    }
                })
                .setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finishAffinity();
                    }
                });
        alertDialogBuilder.show();

    }


    private void NextQuestion(int num){
        if(wrong==2)
        {
            GameOver();
        }
        else if(questionNumber==5) {
            winGame();
        }
        else {
            click = false;
            tv_question.setText(question.getQuestion(num));
            btn_opta.setText(question.getchoice1(num));
            btn_optb.setText(question.getchoice2(num));
            btn_optc.setText(question.getchoice3(num));
            btn_optd.setText(question.getchoice4(num));

            answer = question.getCorrectAnswer(num);
        }
        questionNumber++;
    }





    private void clearColor(){
        btn_opta.setBackgroundColor(Color.WHITE);
        btn_optb.setBackgroundColor(Color.WHITE);
        btn_optc.setBackgroundColor(Color.WHITE);
        btn_optd.setBackgroundColor(Color.WHITE);

    }




    private void clearChecked() {
        btn_opta.setChecked(false);
        btn_optb.setChecked(false);
        btn_optc.setChecked(false);
        btn_optd.setChecked(false);
        btn_opta.setEnabled(true);
        btn_optb.setEnabled(true);
        btn_optc.setEnabled(true);
        btn_optd.setEnabled(true);
    }



}
