package com.abc.quizapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static android.graphics.Color.GREEN;
import static android.graphics.Color.RED;
import static android.graphics.Color.WHITE;
import static android.graphics.Color.parseColor;

public class QuestionScreen extends AppCompatActivity implements View.OnClickListener {


    private ImageView home;
    Button btn_opta, btn_optb, btn_optc, btn_optd;
    TextView tv_question, tv_Score;
    int wrong = 0, score = 0;
    boolean click = false;
    private DatabaseHelper dbhelper;

    private String answer;

    Random random;
    private Button btn_next;


    Question question = new Question();
    int questionLength = question.questions.length;
    private int questionNumber = 0;
    private RecyclerView recyclerView;
    private String name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question_screen);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        dbhelper = new DatabaseHelper(this);
        name = PlayExit.playerName;


        random = new Random();

        btn_opta = findViewById(R.id.btn_opta);
        btn_opta.setOnClickListener(this);
        btn_optb = findViewById(R.id.btn_optb);
        btn_optb.setOnClickListener(this);
        btn_optc = findViewById(R.id.btn_optc);
        btn_optc.setOnClickListener(this);
        btn_optd = findViewById(R.id.btn_optd);
        btn_optd.setOnClickListener(this);
        btn_next = findViewById(R.id.btn_next);


        tv_question = findViewById(R.id.tv_question);
        tv_Score = findViewById(R.id.tv_Score);
        NextQuestion(random.nextInt(questionLength));

        home = findViewById(R.id.home);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(QuestionScreen.this);
                alertDialogBuilder
                        .setMessage("Are you sure you want to go back to home?")
                        .setCancelable(false)
                        .setPositiveButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        })
                        .setNegativeButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                startActivity(new Intent(getApplicationContext(), PlayExit.class));
                            }
                        });
                alertDialogBuilder.show();
                dbhelper.insertData(name, score);

            }
        });


        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {

                    clearColor();
                    NextQuestion(random.nextInt(questionLength));
                    Log.e("tag", "working");
                } catch (Exception e) {
                    e.printStackTrace();

                }
            }
        });

    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btn_opta:
                if (click == false) {
                    if (btn_opta.getText() == answer) {
                        btn_opta.setBackgroundColor(GREEN);
                        score = (score + 5);

                    } else {
                        btn_opta.setBackgroundColor(RED);
                        score = (score - 5);
                        makeGreen();
                        if (wrong == 0 || wrong == 1)
                            wrong++;
                    }
                    tv_Score.setText("" + score);
                    click = true;
                    break;
                }

            case R.id.btn_optb:
                if (click == false) {
                    if (btn_optb.getText() == answer) {
                        btn_optb.setBackgroundColor(GREEN);
                        score = (score + 5);
                    } else {
                        btn_optb.setBackgroundColor(RED);
                        makeGreen();
                        score = (score - 5);
                        if (wrong == 0 || wrong == 1)
                            wrong++;

                    }
                    tv_Score.setText("" + score);
                    click = true;
                    break;
                }

            case R.id.btn_optc:
                if (click == false) {
                    if (btn_optc.getText() == answer) {
                        btn_optc.setBackgroundColor(GREEN);
                        score = (score + 5);
                    } else {
                        btn_optc.setBackgroundColor(RED);
                        makeGreen();
                        score = (score - 5);
                        if (wrong == 0 || wrong == 1)
                            wrong++;

                    }
                    tv_Score.setText("" + score);
                    click = true;
                    break;
                }

            case R.id.btn_optd:
                if (click == false) {
                    if (btn_optd.getText() == answer) {
                        btn_optd.setBackgroundColor(GREEN);
                        score = (score + 5);
                    } else {
                        btn_optd.setBackgroundColor(RED);
                        makeGreen();
                        score = (score - 5);
                        if (wrong == 0 || wrong == 1)
                            wrong++;

                    }
                    tv_Score.setText("" + score);
                    click = true;
                    break;
                }
        }
        questionNumber++;
    }


    private void makeGreen() {

        if (btn_opta.getText().equals(answer))
            btn_opta.setBackgroundColor(GREEN);
        else if (btn_optb.getText().equals(answer))
            btn_optb.setBackgroundColor(GREEN);
        else if (btn_optc.getText().equals(answer))
            btn_optc.setBackgroundColor(GREEN);
        else if (btn_optd.getText().equals(answer))
            btn_optd.setBackgroundColor(GREEN);
    }


    public void onBackPressed() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setTitle("Closing Application");
        alertDialog.setMessage(" " + "Are you sure you want to close this app?");
        alertDialog.setPositiveButton("EXIT", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Intent i = new Intent(QuestionScreen.this, PlayExit.class);    //QuestionScreen.class,RadioQuestion
                startActivity(i);
            }
        });
        alertDialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }

    private void GameOver() {

        dbhelper.insertData(name, score);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(QuestionScreen.this);
        alertDialogBuilder
                .setMessage("Game Over!!\nYour score is  " + score)
                .setCancelable(false)
                .setPositiveButton("New Game", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(getApplicationContext(), PlayExit.class));
                    }
                })
                .setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finishAffinity();
                    }
                });
        alertDialogBuilder.show();

    }

    private void winGame() {
        dbhelper.insertData(name, score);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(QuestionScreen.this);
        alertDialogBuilder
                .setMessage("Congrats!!You win this game")
                .setCancelable(false)
                .setPositiveButton("New Game", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(getApplicationContext(), QuestionScreen.class));
                    }
                })
                .setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finishAffinity();
                    }
                });
        alertDialogBuilder.show();

    }


    private void NextQuestion(int num) {
        if (wrong == 2) {
            GameOver();
        } else if (questionNumber == 5) {
            winGame();
        } else {
            click = false;
            tv_question.setText(question.getQuestion(num));
            btn_opta.setText(question.getchoice1(num));
            btn_optb.setText(question.getchoice2(num));
            btn_optc.setText(question.getchoice3(num));
            btn_optd.setText(question.getchoice4(num));

            answer = question.getCorrectAnswer(num);
        }
    }


    private void clearColor() {
        btn_opta.setBackgroundColor(Color.WHITE);
        btn_optb.setBackgroundColor(Color.WHITE);
        btn_optc.setBackgroundColor(Color.WHITE);
        btn_optd.setBackgroundColor(Color.WHITE);

    }


}
