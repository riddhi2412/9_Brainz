package com.abc.quizapp;

import android.util.Log;

/**
 * Created by jay on 23/5/2018.
 */

public class Question {


    public String questions[] = {
            "When we celebrate Independence day?",
            "When we celebrate Republic day?",
            "When we celebrate Gandhi Jayanti?",
            "Who wrote the national anthem?",
            "Which is the festival of color?"
    };

    public String choices[][] = {
            {"12th July", "15th December", "26th January", "15th August"},
            {"2nd October", "26th January", "15th January", "21st July"},
            {"26th August", "15th November", "2nd October", "5th April"},
            {"Rabindranath Tagore", "Mahatma Gandhi", "Sardar Patel", "Javaharlal Nehru"},
            {"Diwali", "Holi", "Ramnavami", "Janmastami"}
    };

    public String correctAnswer[] = {
            "15th August",
            "26th January",
            "2nd October",
            "Rabindranath Tagore",
            "Holi"
    };

    public String getQuestion(int a){
        String question = questions[a];
        return question;

    }

    public String getchoice1(int a){
        String choice = choices[a][0];
        return choice;
    }

    public String getchoice2(int a){
        String choice = choices[a][1];
        return choice;
    }

    public String getchoice3(int a){
        String choice = choices[a][2];
        return choice;
    }

    public String getchoice4(int a){
        String choice = choices[a][3];
        return choice;
    }

    public String getCorrectAnswer(int a){
        String answer = correctAnswer[a];
        return answer;
    }

}
