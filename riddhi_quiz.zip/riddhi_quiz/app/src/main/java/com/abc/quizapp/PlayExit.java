package com.abc.quizapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class PlayExit extends AppCompatActivity {

    private ImageButton play;
    private ImageButton exit;
    boolean elligible=false;

    DatabaseHelper myDb;
    public static String playerName="";
    private Button btn_score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play_exit);
        myDb=new DatabaseHelper(this);
        btn_score = findViewById(R.id.btn_score);
        btn_score.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent score = new Intent(PlayExit.this,DisplayScore3.class);
                startActivity(score);
            }
        });
    }


    public void playClick(View view) {
        play=findViewById(R.id.play);

        final EditText input=new EditText(this);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter your name");


        input.setInputType(InputType.TYPE_CLASS_TEXT  /* | InputType.TYPE_TEXT_VARIATION_PASSWORD*/);
        builder.setView(input);


        AlertDialog.Builder ok = builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                playerName = input.getText().toString();
                if (!playerName.isEmpty() && !playerName.contains(" ")) {
                    Intent i = new Intent(PlayExit.this, QuestionScreen.class);    //QuestionScreen.class,RadioQuestion
                    startActivity(i);
                }
                else
                    Toast.makeText(PlayExit.this, "Please enter a Name without space", Toast.LENGTH_SHORT).show();
                //elligible=true;
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();

      /*  if(elligible==true) {
            Intent i = new Intent(this, QuestionScreen.class);    //QuestionScreen.class,RadioQuestion
            startActivity(i);
        }*/

    }

    public void exitClick(View view){
       onBackPressed();
    }

    @Override
    public void onBackPressed() {
        exit=findViewById(R.id.exit);
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setTitle("Closing Application");
        alertDialog.setMessage(" " + "Are you sure you want to close this app?");
        alertDialog.setIcon(R.drawable.exit);
        alertDialog.setPositiveButton("EXIT", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {
                finishAffinity();
            }
        });
        alertDialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }
}
