package com.abc.quizapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by riddhi on 25/5/2018.
 */


public class DisplayScore3  extends AppCompatActivity{

    private RecyclerView recyclerView;
    private AdapterClass mAdapter;
    private DatabaseHelper db;
    private ArrayList<detail> scoreList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_score3);


        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        db = new DatabaseHelper(this);

       scoreList = new ArrayList<detail>();
        scoreList = db.getAllNotes();

        mAdapter = new AdapterClass(scoreList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(mAdapter);
    }
    class AdapterClass extends RecyclerView.Adapter<AdapterClass.MyViewHolder> {

        ArrayList<detail> detailsList;

        class MyViewHolder extends RecyclerView.ViewHolder {
            public TextView id, name, score;

            public MyViewHolder(View view) {
                super(view);
                id = (TextView) view.findViewById(R.id.id);
                score = (TextView) view.findViewById(R.id.score);
                name = (TextView) view.findViewById(R.id.name);
            }
        }


        public AdapterClass(ArrayList<detail> detailsList) {
            this.detailsList = detailsList;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.score_board, parent, false);
            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            detail detail = detailsList.get(position);
            holder.id.setText(""+(position+1));
            holder.name.setText(detail.getName());
            holder.score.setText(""+detail.getScore());
        }

        @Override
        public int getItemCount() {
            return detailsList.size();
        }

    }

}
