package Interface;


import Module.DataSucessOutput;
import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by riddhi on 19/5/2018.
 */

public interface DataSuccess {

        @GET("RetrofitAndroidObjectResponse")
        Call<DataSucessOutput> DataSucessMethod();


}
