package Module;

/**
 * Created by jay on 19/5/2018.
 */

public class DataSucessOutput {

    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("StudentMarks")
    private String StudentMarks;
    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("StudentName")
    private String StudentName;
    @com.google.gson.annotations.Expose
    @com.google.gson.annotations.SerializedName("StudentId")
    private String StudentId;

    public String getStudentMarks() {
        return StudentMarks;
    }

    public void setStudentMarks(String StudentMarks) {
        this.StudentMarks = StudentMarks;
    }

    public String getStudentName() {
        return StudentName;
    }

    public void setStudentName(String StudentName) {
        this.StudentName = StudentName;
    }

    public String getStudentId() {
        return StudentId;
    }

    public void setStudentId(String studentId) {
        StudentId = studentId;
    }
}
