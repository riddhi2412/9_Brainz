package com.abc.projectapi;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.concurrent.TimeUnit;

import Interface.DataSuccess;
import Module.DataSucessOutput;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    TextView tv_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        tv_result=findViewById(R.id.tv_result);
        getApiData();

    }


    private void getApiData(){
        final ProgressDialog pg = new ProgressDialog(MainActivity.this);
        pg.setMessage("Loading..");
        pg.show();

        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(100, TimeUnit.SECONDS)
                .readTimeout(100, TimeUnit.SECONDS).build();
        Retrofit retrofit = new Retrofit.Builder().client(client).baseUrl(Constant.constant.baseUrl).addConverterFactory(GsonConverterFactory.create(gson)).build();
        final DataSuccess requestInterface = retrofit.create(DataSuccess.class);
        final Call<DataSucessOutput> dataSucessOutputCall = requestInterface.DataSucessMethod();

        dataSucessOutputCall.enqueue(new Callback<DataSucessOutput>() {
            @Override
            public void onResponse(Call<DataSucessOutput> call, Response<DataSucessOutput> response) {
                pg.dismiss();
                try{
                    if(response.isSuccessful()){
                        Log.e("response","working");
                        String id=response.body().getStudentId();
                        String name=response.body().getStudentName();
                        String marks=response.body().getStudentMarks();
                        tv_result.setText(""+id+"  "+name+"  "+marks);
                    }
                    else {
                        Log.e("response","not working");
                        Toast.makeText(MainActivity.this, "please try again", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<DataSucessOutput> call, Throwable t) {
                pg.dismiss();
                Toast.makeText(MainActivity.this, "please check your internet", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}






