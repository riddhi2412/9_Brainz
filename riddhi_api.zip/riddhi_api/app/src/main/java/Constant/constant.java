package Constant;

/**
 * Created by jay on 19/5/2018.
 */

public class constant {
    public static String baseUrl="https://androidtutorialpoint.com/api/";

}
