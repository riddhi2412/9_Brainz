package Constant;

/**
 * Created by riddhi on 30/5/2018.
 */

public class Cons {

        public static String baseUrl="https://www.thegreatapps.com/rest_api/";

}
