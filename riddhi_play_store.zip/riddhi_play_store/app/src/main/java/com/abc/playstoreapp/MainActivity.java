package com.abc.playstoreapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.squareup.picasso.Picasso;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import Constant.Cons;
import Interface.SucessInterface;
import Module.AppRatings;
import Module.Data;
import Module.MainGenerator;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {


    private RecyclerView recyclerView;
    private AdapterClass mAdapter;
    String TotalAvgRating, TotalVotes, AppName, AppIcon;
    private ArrayList<DataClass> applist = new ArrayList<>();
    private ImageView img_load;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycler_view);

        mAdapter = new AdapterClass(this,applist);


        GridLayoutManager manager = new GridLayoutManager(this, 3, GridLayoutManager.VERTICAL, false);

        recyclerView.setLayoutManager(manager);

        recyclerView.setAdapter(mAdapter);
        getApiData();
    }


    private void getApiData() {


        final ProgressDialog pg = new ProgressDialog(MainActivity.this);
        pg.setMessage("Loading..");
        pg.show();
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(100, TimeUnit.SECONDS)
                .readTimeout(100, TimeUnit.SECONDS).build();
        Retrofit retrofit = new Retrofit.Builder().client(client).baseUrl(Cons.baseUrl).addConverterFactory(GsonConverterFactory.create(gson)).build();
        final SucessInterface requestInterface = retrofit.create(SucessInterface.class);
        String url = "apps_gallery_listing?Type=android&CategoryType=game&PageNo=1";
        final Call<MainGenerator> mainGeneratorCall = requestInterface.OutputMethod(url);

        mainGeneratorCall.enqueue(new Callback<MainGenerator>() {
            @Override
            public void onResponse(Call<MainGenerator> call, Response<MainGenerator> response) {
                pg.dismiss();
                if (response.isSuccessful()) {
                    for (int i = 0; i < response.body().getData().getAppsData().size(); i++) {
                        AppName = response.body().getData().getAppsData().get(i).getAppName();
                        AppIcon = response.body().getData().getAppsData().get(i).getAppIcon();
                        TotalVotes = response.body().getData().getAppsData().get(i).getAppRatings().getTotalVotes();
                        TotalAvgRating = response.body().getData().getAppsData().get(i).getAppRatings().getTotalAvgRating();
                        DataClass dt = new DataClass();

                        ArrayList<AppRatingsClass> appRatingsArrayList = new ArrayList<AppRatingsClass>();
                        AppRatingsClass appRatings = new AppRatingsClass();
                        appRatings.setAVG_CreativityRating(response.body().getData().getAppsData().get(i).getAppRatings().getAVG_CreativityRating());
                        appRatings.setAVG_DesignRating(response.body().getData().getAppsData().get(i).getAppRatings().getAVG_DesignRating());
                        appRatings.setAVG_UsabilityRating(response.body().getData().getAppsData().get(i).getAppRatings().getAVG_UsabilityRating());
                        appRatings.setTotalAvgRating(response.body().getData().getAppsData().get(i).getAppRatings().getTotalAvgRating());
                        appRatings.setTotalVotes(response.body().getData().getAppsData().get(i).getAppRatings().getTotalVotes());
                        appRatingsArrayList.add(appRatings);
                        dt.setAppRatings(appRatingsArrayList);


                        ArrayList<DataClass> dataClassArrayList = new ArrayList<DataClass>();
                        dt.setAppName(response.body().getData().getAppsData().get(i).getAppName());
                        dt.setAppIcon(response.body().getData().getAppsData().get(i).getAppIcon());
                        dt.setaClass(response.body().getData().getAppsData().get(i).getaClass());
                        dt.setAndroidURL(response.body().getData().getAppsData().get(i).getAndroidURL());
                        dt.setAppType(response.body().getData().getAppsData().get(i).getAppType());
                        dt.setCategoryID(response.body().getData().getAppsData().get(i).getCategoryID());
                        dt.setAppID(response.body().getData().getAppsData().get(i).getAppID());
                        dt.setTagID(response.body().getData().getAppsData().get(i).getTagID());
                        dataClassArrayList.add(dt);
                        applist.add(dt);

                    }
                    mAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(MainActivity.this, "try again", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<MainGenerator> call, Throwable t) {
                Toast.makeText(MainActivity.this, "check your internet connection", Toast.LENGTH_SHORT).show();

            }
        });
    }


}




