package com.abc.playstoreapp;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.graphics.Movie;
import android.net.Uri;

import android.support.v7.widget.RecyclerView;
import android.util.Log;

import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import Module.Data;

/**
 * Created by riddhi on 29/5/2018.
 */

public class AdapterClass extends RecyclerView.Adapter<AdapterClass.MyViewHolder> {


    private ArrayList<DataClass> applist = new ArrayList<>();
    private Context context;
    private Button btn_play;
    public static String img,name,link,rate,vote;
    public TextView tv_name, tv_ratings, tv_vote;
    public ImageView img_load;
    //  public static String type;


    public class MyViewHolder extends RecyclerView.ViewHolder {


        public TextView tv_name,tv_ratings, tv_vote;
        public ImageView img_load;

        public MyViewHolder(View view) {
            super(view);
            tv_name = (TextView) view.findViewById(R.id.tv_name);
            tv_ratings = (TextView) view.findViewById(R.id.tv_ratings);
            tv_vote = (TextView) view.findViewById(R.id.tv_vote);
            img_load = view.findViewById(R.id.img_load);
            btn_play = view.findViewById(R.id.btn_ply);
        }
    }


    public AdapterClass(MainActivity mainActivity, ArrayList<DataClass> applist) {

        this.applist = applist;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.grid_layout, parent, false);

        context = parent.getContext();
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {
        final DataClass dataClass = applist.get(position);
        holder.tv_name.setText(dataClass.AppName);
        holder.tv_vote.setText(dataClass.getAppRatings().get(0).getTotalVotes() + " users voted");
        holder.tv_ratings.setText(dataClass.getAppRatings().get(0).getTotalAvgRating());
        Picasso.with(context).load(dataClass.AppIcon).placeholder(R.drawable.icon).error(R.drawable.icon).into(holder.img_load, new com.squareup.picasso.Callback() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onError() {
            }
        });


        holder.img_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("click", "working..");
                Intent intent=new Intent(context,DisplayPage.class);
                img = dataClass.getAppIcon();
                name = dataClass.getAppName();
                link = dataClass.getAndroidURL();
                rate=dataClass.AppRatings.get(0).getTotalAvgRating();
                vote=dataClass.AppRatings.get(0).getTotalVotes();
             //   type=dataClass.getAppType();

                Pair[] pairs=new Pair[4];
                pairs[0]=new Pair<View,String>(holder.img_load,"imgtr");
                pairs[1]=new Pair<View,String>(holder.tv_name,"nmtr");
                pairs[2]=new Pair<View,String>(holder.tv_vote,"votegtr");
                pairs[3]=new Pair<View,String>(holder.tv_ratings,"ratetr");


                ActivityOptions options=ActivityOptions.makeSceneTransitionAnimation((Activity)context,pairs);
                context.startActivity(intent,options.toBundle());



            }
        });
        btn_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String url = dataClass.getAndroidURL();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                context.startActivity(i);


            }
        });


    }

    @Override
    public int getItemCount() {
        return applist.size();
    }
}

