package com.abc.playstoreapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import Constant.Cons;
import Interface.SucessInterface;
import Module.MainGenerator;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DisplayPage extends AppCompatActivity {


    private ImageView img_icon;
    public TextView tv_dname,tv_dratings,tv_dvote;
    private Context context;
    private String TotalVotes,TotalAvgRating;
    private Button btn_play_store;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_page);
        getWindow().getExitTransition();

        img_icon=findViewById(R.id.img_icon);
        tv_dname = (TextView) findViewById(R.id.tv_dname);
        tv_dratings = (TextView) findViewById(R.id.tv_dratings);
        tv_dvote = (TextView) findViewById(R.id.tv_dvote);
        btn_play_store = findViewById(R.id.btn_play_store);

        String icon = AdapterClass.img;
        Picasso.with(context).load(icon).placeholder(R.drawable.icon).error(R.drawable.icon).into(img_icon, new com.squareup.picasso.Callback() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onError() {
            }
        });
        String name = AdapterClass.name;
        String rate=AdapterClass.rate;
        String vote =AdapterClass.vote;

        tv_dname.setText(name);
        tv_dratings.setText(rate+" users voted");
        tv_dvote.setText(vote);
      //  final String type=AdapterClass.type;


        final String link = AdapterClass.link;

        btn_play_store.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                /*Intent promptInstall = new Intent(Intent.ACTION_VIEW)
                        .setDataAndType(Uri.parse(link),
                                type);
                startActivity(promptInstall);*/

              Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(link));
                startActivity(i);


            }
        });



    }
}
