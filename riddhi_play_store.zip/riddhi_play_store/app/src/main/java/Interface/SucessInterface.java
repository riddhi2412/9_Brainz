package Interface;



import Module.MainGenerator;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;

/**
 * Created by riddhi on 30/5/2018.
 */

public interface SucessInterface {

    @GET()
    Call<MainGenerator> OutputMethod(@Url String url);

}
